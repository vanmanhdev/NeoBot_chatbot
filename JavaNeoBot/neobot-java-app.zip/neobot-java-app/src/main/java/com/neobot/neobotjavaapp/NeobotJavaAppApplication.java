package com.neobot.neobotjavaapp;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class NeobotJavaAppApplication {

	public static void main(String[] args) {
		SpringApplication.run(NeobotJavaAppApplication.class, args);
	}

}
