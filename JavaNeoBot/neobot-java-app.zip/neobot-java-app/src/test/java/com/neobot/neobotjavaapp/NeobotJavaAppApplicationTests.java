package com.neobot.neobotjavaapp;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class NeobotJavaAppApplicationTests {

	@Test
	void contextLoads() {
	}

}
